## Overview
The files in this directory are the CA files from an Amazon Linux 2012 Image. They are copied from /etc/pki/tls/certs.

## CA
- ca-bundle.crt
- ca-bundle.trust.crt
