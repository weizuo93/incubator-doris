This directory is used to store build artifacts (tarballs and source) for a locally
built copy of libcrypto, either from OpenSSL, LibreSSL or BoringSSL.

See the s2n [Usage Guide](https://github.com/awslabs/s2n/blob/master/docs/USAGE-GUIDE.md) for more details.
