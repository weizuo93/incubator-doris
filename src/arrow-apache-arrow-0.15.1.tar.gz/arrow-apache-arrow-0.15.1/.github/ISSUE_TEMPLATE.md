STOP! Are you reporting a bug, a possible bug, or requesting a
feature? If so, please report under the ARROW project on the ASF JIRA
server https://issues.apache.org/jira/browse/ARROW. This JIRA server
is free to use and open to the public, but you must create an account
if it is your first time.

See our contribution guidelines for more information:
http://arrow.apache.org/docs/developers/contributing.html

We have GitHub issues available as a way for new contributors and
passers-by who are unfamiliar with Apache Software Foundation projects
to ask questions and interact with the project. Do not be surprised if
the first response is to open a JIRA issue or to write an e-mail to
one of the public mailing lists:

* Development discussions: dev@arrow.apache.org (first subscribe by
  sending an e-mail to dev-subscribe@arrow.apache.org).
* User discussions: user@arrow.apache.org (first subscribe by
  sending an e-mail to user-subscribe@arrow.apache.org).

Thank you!