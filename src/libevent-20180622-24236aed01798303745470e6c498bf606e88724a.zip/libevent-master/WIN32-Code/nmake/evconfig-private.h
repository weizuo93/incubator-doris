#if !defined(EVENT_EVCONFIG__PRIVATE_H_) && !defined(__MINGW32__)
#define EVENT_EVCONFIG__PRIVATE_H_

/* Nothing to see here.  Move along. */

#endif
