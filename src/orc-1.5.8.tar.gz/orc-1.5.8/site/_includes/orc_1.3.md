The new features of ORC 1.3:

- [ORC-58]({{site.jira}}/ORC-58) Split C++ Reader into Reader and RowReader
- [ORC-120]({{site.jira}}/ORC-120) Add backwards compatibility mode for schema evolution.
- [ORC-124]({{site.jira}}/ORC-124) Fast decimal improvements
- [ORC-128]({{site.jira}}/ORC-128) Add ability to get statistics from writer


